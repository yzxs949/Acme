﻿using System;
using System.IO;

namespace Acme;


/// <summary>
/// 系统配置参数
/// </summary>
public static class App
{
    private static JsonFile _jsonFileVariable { get; set; }

    /// <summary>
    /// 构造函数
    /// </summary>
    static App()
    {
        _jsonFileVariable = new("appsettings.json");
    }

    /// <summary>
    /// 获取配置文件中的值
    /// </summary>
    /// <param name="key">键</param>
    /// <param name="name">名称</param>
    /// <returns></returns>
    public static string GetValue(string key, string name)
    {
        return _jsonFileVariable.GetValue(key, name);
    }

    /// <summary>
    /// 获取配置文件中的值
    /// </summary>
    /// <param name="key">键</param>
    /// <returns></returns>
    public static string GetValue(string key)
    {
        return _jsonFileVariable.GetValue(key);
    }

    /// <summary>
    /// 系统路径
    /// </summary>
    public static string SystemPath => Directory.GetCurrentDirectory();

    /// <summary>
    /// 系统路径
    /// </summary>
    public static string Path => AppDomain.CurrentDomain.BaseDirectory;
}