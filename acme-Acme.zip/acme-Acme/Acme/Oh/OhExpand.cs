﻿namespace Acme
{
    /// <summary>
    /// Oh拓展类
    /// </summary>
    public static class OhExpand
    {
        /// <summary>
        /// 获取成功时的Oh值
        /// </summary>
        /// <param name="data">数据</param>
        /// <param name="msg">描述</param>
        /// <returns></returns>
        public static Oh Success(
            this object data,
            string msg = CV.Yes)
        {
            return new Oh(CV.YesCode, msg, data);
        }

        /// <summary>
        /// 获取成功时的Oh值
        /// </summary>
        /// <param name="data">数据</param>
        /// <param name="msg">描述</param>
        /// <returns></returns>
        public static Oh<TEntity> Success<TEntity>(
            this TEntity data,
            string msg = CV.Yes) where TEntity : class, new()
        {
            return new Oh<TEntity>(CV.YesCode, msg, data);
        }

        /// <summary>
        /// 获取成功时的Oh值
        /// </summary>
        /// <param name="data">数据</param>
        /// <returns></returns>
        public static Oh Success(
            this object data)
        {
            return new Oh(CV.YesCode, CV.Yes, data);
        }

        /// <summary>
        /// 获取成功时的Oh值
        /// </summary>
        /// <param name="data">数据</param>
        /// <returns></returns>
        public static Oh<TEntity> Success<TEntity>(
            this TEntity data) where TEntity : class, new()
        {
            return new Oh<TEntity>(CV.YesCode, CV.Yes, data);
        }

        /// <summary>
        /// 获取成功时的Oh值
        /// </summary>
        /// <param name="data">数据</param>
        /// <param name="code">状态码</param>
        /// <param name="msg">描述</param>
        /// <returns></returns>
        public static Oh Success(
            this object data,
            int code = CV.YesCode,
            string msg = CV.Yes)
        {
            return new Oh(code, msg, data);
        }

        /// <summary>
        /// 获取成功时的Oh值
        /// </summary>
        /// <param name="data">数据</param>
        /// <param name="code">状态码</param>
        /// <param name="msg">描述</param>
        /// <returns></returns>
        public static Oh<TEntity> Success<TEntity>(
            this TEntity data,
            int code = CV.YesCode,
            string msg = CV.Yes) where TEntity : class, new()
        {
            return new Oh<TEntity>(code, msg, data);
        }

        /// <summary>
        /// 获取失败时的Oh值
        /// </summary>
        /// <param name="data">数据</param>
        /// <param name="msg">描述</param>
        /// <returns></returns>
        public static Oh Fail(
            this object data,
            string msg = CV.ErrorServer)
        {
            return new Oh(CV.NoCode, msg, data);
        }

        /// <summary>
        /// 获取失败时的Oh值
        /// </summary>
        /// <param name="data">数据</param>
        /// <param name="msg">描述</param>
        /// <returns></returns>
        public static Oh<TEntity> Fail<TEntity>(
            this TEntity data,
            string msg = CV.ErrorServer) where TEntity : class, new()
        {
            return new Oh<TEntity>(CV.NoCode, msg, data);
        }

        /// <summary>
        /// 获取失败时的Oh值
        /// </summary>
        /// <param name="data">数据</param>
        /// <returns></returns>
        public static Oh Fail(
            this object data)
        {
            return new Oh(CV.NoCode, CV.ErrorServer, data);
        }

        /// <summary>
        /// 获取失败时的Oh值
        /// </summary>
        /// <param name="data">数据</param>
        /// <returns></returns>
        public static Oh<TEntity> Fail<TEntity>(
            this TEntity data) where TEntity : class, new()
        {
            return new Oh<TEntity>(CV.NoCode, CV.ErrorServer, data);
        }

        /// <summary>
        /// 获取失败时的Oh值
        /// </summary>
        /// <param name="data">数据</param>
        /// <param name="code">状态码</param>
        /// <param name="msg">描述</param>
        /// <returns></returns>
        public static Oh Fail(
            this object data,
            int code = CV.NoCode,
            string msg = CV.ErrorServer)
        {
            return new Oh(code, msg, data);
        }

        /// <summary>
        /// 获取失败时的Oh值
        /// </summary>
        /// <param name="data">数据</param>
        /// <param name="code">状态码</param>
        /// <param name="msg">描述</param>
        /// <returns></returns>
        public static Oh<TEntity> Fail<TEntity>(
            this TEntity data,
            int code = CV.NoCode,
            string msg = CV.ErrorServer) where TEntity : class, new()
        {
            return new Oh<TEntity>(code, msg, data);
        }

        /// <summary>
        /// 自定义状态码
        /// </summary>
        /// <param name="data">数据</param>
        /// <param name="code">状态码</param>
        /// <param name="msg">描述</param>
        /// <returns></returns>
        public static Oh Custom(
            this object data,
            int code,
            string msg)
        {
            return new Oh(code, msg, data);
        }

        /// <summary>
        /// 自定义状态码
        /// </summary>
        /// <param name="data">数据</param>
        /// <param name="code">状态码</param>
        /// <param name="msg">描述</param>
        /// <returns></returns>
        public static Oh<TEntity> Custom<TEntity>(
            this TEntity data,
            int code,
            string msg) where TEntity : class, new()
        {
            return new Oh<TEntity>(code, msg, data);
        }
    }
}
